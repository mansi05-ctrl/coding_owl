<!doctype html>
<html>

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>grampanyat dashboard</title>
    <link rel="stylesheet" href="main.css">
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
   

</head>
<body>

<div class="main">
        <!-- <iframe id="iframe-content" width="100%" height="100%" frameborder="0"></iframe> -->
         <div class="main-header">
                <div class="main-header__heading">Hello User</div>
                <div class="main-header__updates">Recent Items</div> 
           </div>

           <div class="main-overview">
            <div class="overviewcard">
              <div class="overviewcard__icon">Overview</div>
              <div class="overviewcard__info">Card</div>
            </div>
            <div class="overviewcard">
              <div class="overviewcard__icon">Overview</div>
              <div class="overviewcard__info">Card</div>
            </div>
            <div class="overviewcard">
              <div class="overviewcard__icon">Overview</div>
              <div class="overviewcard__info">Card</div>
            </div>
            <div class="overviewcard">
              <div class="overviewcard__icon">Overview</div>
              <div class="overviewcard__info">Card</div>
            </div>
          </div>

          <div class="main-cards">
            <div class="card">Card</div>
            <div class="card">Card</div>
            <div class="card">Card</div>
          </div>



        </div>
</body>
</html>