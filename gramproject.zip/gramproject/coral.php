<!DOCTYPE html>
<html>
<head>
  <title>Your Page Title</title>
  <link rel="stylesheet" type="text/css" href="about.css">
</head>
<body>

<div class="wrapper">
    <div class="slider">
      <div class="slide">
        <img src="digital_india.jpg" alt="Logo 1"></a>
<a href="url2"><img src="moefrd.png" alt="Logo 2"></a>
<a href="url3"><img src="mfopr.jpeg" alt="Logo 3"></a>
<a href="url4"><img src="make.jpeg" alt="Logo 4"></a>
<a href="url5"><img src="incredible.jpeg" alt="Logo 5"></a>
<a href="url6"><img src="health.png" alt="Logo 6"></a>
<a href="url7"><img src="gov.png" alt="Logo 7"></a>

      </div>
      <div class="slide">
        <img src="digital_india.jpg" alt="Logo 1"></a>
<a href="url2"><img src="moefrd.png" alt="Logo 2"></a>
<a href="url3"><img src="mfopr.jpeg" alt="Logo 3"></a>
<a href="url4"><img src="make.jpeg" alt="Logo 4"></a>
<a href="url5"><img src="incredible.jpeg" alt="Logo 5"></a>
<a href="url6"><img src="health.png" alt="Logo 6"></a>
<a href="url7"><img src="gov.png" alt="Logo 7"></a>

      
      </div>
    </div>
</div>
</body>
</html>